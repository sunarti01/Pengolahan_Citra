def compress_RLE(data):
    compressed_data = ""
    count = 1

    for i in range(len(data)-1):
        if data[i] == data[i+1]:
            count += 1
        else:
            compressed_data += str(count) + data[i]
            count = 1

    # Menambahkan pasangan angka dan karakter terakhir
    compressed_data += str(count) + data[-1]

    return compressed_data

data = "SUUUNNAAARRTTTII"
compressed_data = compress_RLE(data)
print(compressed_data)  # Output: "1S3U2N4A3R4T2I"